import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-pdf',
  templateUrl: './content-pdf.component.html',
  styleUrls: ['./content-pdf.component.scss']
})
export class ContentPdfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
