import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-jd',
  templateUrl: './view-jd.component.html',
  styleUrls: ['./view-jd.component.scss']
})
export class ViewJdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
